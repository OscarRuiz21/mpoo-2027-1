package streaming;

public abstract class Contenido{
    private final String titulo;
    private final int minutos;
    //Constructor
    protected Contenido (String titulo , int minutos){
        this.titulo = titulo;
        this.minutos = minutos;
    }
    //. METODODS. Aqui se dice que todo contenido se reproduce pero las clases hijas se encargan de decir como se van a repoducir
    public abstract String reproducir();
    public String getTitulo(){
        return titulo; 
    }
    public int getMinutos(){
        return minutos;
    }
}
