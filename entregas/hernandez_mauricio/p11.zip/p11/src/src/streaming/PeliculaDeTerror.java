/*package streaming;
public class PeliculaDeTerror extends Pelicula{
    public PeliculaDeTerror(String titulo, int minutos){
        super(titulo, minutos);
    }
}*/