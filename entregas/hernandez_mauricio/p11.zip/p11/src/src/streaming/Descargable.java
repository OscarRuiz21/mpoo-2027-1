package streaming;
public interface Descargable{
    //¿cuanto espacio ocupa?
    double megas();
}