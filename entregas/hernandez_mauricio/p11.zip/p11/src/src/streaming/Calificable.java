/*Al tratarse de interfaces todo lo que se encuentre de dicha interfaz se considera publico y abstracto, por lo que no es necesario el declarar los metodos con algun tipo de modificador de tipo
public, private, protected, etc. a menos que asi se desee. */
package streaming;
public interface Calificable {
    void calificar (int estrellas);
    double promedio(); 
}